package com.pearnode.blaze.triptoe

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.support.multidex.MultiDex
import android.support.v4.app.ActivityCompat
import android.support.v7.app.AlertDialog
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.Toast
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.api.GoogleApiClient
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationServices
import com.google.android.gms.tasks.OnSuccessListener
import kotlinx.android.synthetic.main.activity_home.*
import kotlinx.android.synthetic.main.dialog_create_transport.view.*


class HomeActivity : AppCompatActivity(), GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener, com.google.android.gms.location.LocationListener {


    var client: GoogleApiClient? = null
    var locationRequest: LocationRequest? = null
    var address = ""

    var latitude: Double? = null
    var longitude: Double? = null
    var username: String? = null
    var userId: String? = null
    var userType: String? = null

    val TAG = "MainActivity"
    private lateinit var mGoogleApiClient: GoogleApiClient
    private var mLocationManager: LocationManager? = null
    lateinit var mLocation: Location
    private var mLocationRequest: LocationRequest? = null
    private val listener: com.google.android.gms.location.LocationListener? = null
    private val UPDATE_INTERVAL = (2 * 1000).toLong()  /* 10 secs */
    private val FASTEST_INTERVAL: Long = 2000 /* 2 sec */

    lateinit var locationManager: LocationManager


    override fun onStart() {
        super.onStart();
        if (mGoogleApiClient != null) {
            mGoogleApiClient.connect();
        }
    }

    override fun onStop() {
        super.onStop();
        if (mGoogleApiClient.isConnected()) {
            mGoogleApiClient.disconnect();
        }
    }

    override fun onConnected(p0: Bundle?) {
        //To change body of created functions use File | Settings | File Templates.

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            return;
        }


        startLocationUpdates();

        var fusedLocationProviderClient:
                FusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        fusedLocationProviderClient.getLastLocation()
                .addOnSuccessListener(this, OnSuccessListener<Location> { location ->
                    // Got last known location. In some rare situations this can be null.
                    if (location != null) {
                        // Logic to handle location object
                        mLocation = location;
                        /*txt_latitude.setText("" + mLocation.latitude)
                        txt_longitude.setText("" + mLocation.longitude)*/
                    }
                })
    }

    override fun onConnectionSuspended(p0: Int) {
        //To change body of created functions use File | Settings | File Templates.

        Log.i(TAG, "Connection Suspended");
        mGoogleApiClient.connect();
    }

    override fun onConnectionFailed(connectionResult: ConnectionResult) {
        //To change body of created functions use File | Settings | File Templates.
        Log.i(TAG, "Connection failed. Error: " + connectionResult.getErrorCode());
        Log.i(TAG, "Connection failed. Error2: " + connectionResult.errorMessage);
    }

    override fun onLocationChanged(location: Location?) {
        //To change body of created functions use File | Settings | File Templates.

        var msg = "Updated Location: Latitude " + location?.longitude.toString() + location?.longitude;
        // txt_latitude.setText(""+location.latitude);
        //   txt_longitude.setText(""+location.longitude);

        latitude = location?.latitude
        longitude = location?.longitude
        //    Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();

        //  var help : Help = Help()
        //   address = help.getAddress(LatLng(latitude!!,longitude!!))


    }


    /* fun  buildGoogleApiClient()
     {
         client = GoogleApiClient.Builder(this)
                 .addConnectionCallbacks(this)
                 .addOnConnectionFailedListener(this)
                 .addApi(LocationServices.API)
                 .build();
         client.connect();
     }*/


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        MultiDex.install(this@HomeActivity)

        mGoogleApiClient = GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .build()

        mLocationManager = this.getSystemService(Context.LOCATION_SERVICE) as LocationManager

        val editor = getSharedPreferences("truck", Context.MODE_PRIVATE)
        username = editor.getString("username", "username")
        userType = editor.getString("type", "username")
        userId = editor.getString("userId", "username")
        var uniqueId = editor.getString("uniqueId", "username")
        uniqueTxt.text = "your uinque id: $uniqueId"

        if (userType.equals("3", true)) {
            //Turucker

        } else {
            //user
            createTrnsLay.visibility = View.GONE

        }

        crtTsptLay.setOnClickListener(View.OnClickListener {
            if (userType.equals("3", true)) {
                if (latitude != null) {
                    intent = Intent(this, Create::class.java)
                    intent.putExtra("lat", "" + latitude)
                    intent.putExtra("lng", "" + longitude)
                    startActivity(intent);
                } else {
                    Toast.makeText(this, "please wait your location is not updated yet", Toast.LENGTH_LONG).show();
                }


            } else {

            }
        })


        actvTnspLay.setOnClickListener(View.OnClickListener {
            val intent = Intent(this, ActiveTripsActivity::class.java)
            startActivity(intent);
        })


        /*  if(!userType.equals("3",true))
          {
              // This is transporter
              pendingTrnsLay.visibility=View.GONE
              crtTxt.text="Pending Transport"
          }*/

    }


    private fun isLocationEnabled(): Boolean {
        locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) || locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
    }

    protected fun startLocationUpdates() {

        // Create the location request
        mLocationRequest = LocationRequest.create()
                .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
                .setInterval(UPDATE_INTERVAL)
                .setFastestInterval(FASTEST_INTERVAL);
        // Request location updates
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient,
                mLocationRequest, this);
    }


    fun showNewNameDialog() {

        /* val dialogBuilder = AlertDialog.Builder(this)
         val inflater = this.layoutInflater
         val dialogView = inflater.inflate(R.layout.dialog_create_transport, null)
         dialogBuilder.setView(dialogView)

         val userIdEdt = dialogView.findViewById<View>(R.id.userIdEdt) as EditText
         val descEdt = dialogView.findViewById<View>(R.id.descEdt) as EditText
         val submitBtn = dialogView.findViewById<View>(R.id.submitBtn) as Button

         submitBtn.setOnClickListener(View.OnClickListener {

             var IdSend:String?=userIdEdt.text.toString();
             var desc:String?=descEdt.text.toString();
             CreateTransport().execute("http://triptoe.pearnode.com/api_mobile/api/create_new_transport",
                     IdSend,desc)


             })

         dialogBuilder.show()*/

        val mDialogView = LayoutInflater.from(this).inflate(R.layout.dialog_create_transport, null)
        //AlertDialogBuilder
        val mBuilder = AlertDialog.Builder(this)
                .setView(mDialogView)
        // .setTitle("Submit Form")
        //show dialog
        //    val  mAlertDialog = mBuilder.show()
        val mAlertDialog = mBuilder.create()

        mAlertDialog.setCanceledOnTouchOutside(false);
        mAlertDialog.show()
        //login button click of custom layout
        mDialogView.submitBtn.setOnClickListener {
            //dismiss dialog
            val msg = mDialogView.descEdt.text.toString()

            mAlertDialog.dismiss()

        }
    }


}

