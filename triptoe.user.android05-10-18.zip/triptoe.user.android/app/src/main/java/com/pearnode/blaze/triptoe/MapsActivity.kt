package com.pearnode.blaze.triptoe

import android.Manifest
import android.annotation.SuppressLint
import android.app.ProgressDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.AsyncTask
import android.os.Bundle
import android.support.v4.app.ActivityCompat
import android.support.v7.app.AlertDialog
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.Toast
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.api.GoogleApiClient
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.gms.maps.model.PolylineOptions
import com.google.android.gms.tasks.OnSuccessListener
import com.google.gson.Gson
import com.pearnode.blaze.triptoe.model.GoogleMapDTO
import com.pearnode.blaze.triptoe.utils.NetworkUtil
import kotlinx.android.synthetic.main.activity_maps.*
import kotlinx.android.synthetic.main.dialog_submit_transport.view.*
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONException
import org.json.JSONObject
import java.io.*
import java.net.HttpURLConnection
import java.net.MalformedURLException
import java.net.URL
import java.util.*


class MapsActivity : AppCompatActivity(), OnMapReadyCallback, GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener, com.google.android.gms.location.LocationListener {

    var type = ""
    var tranId = ""
    var userId = ""
    var intentType = ""
    var address = ""

    var breaker: Boolean = true;

    var markerChng: Marker? = null


    private lateinit var mMap: GoogleMap

    var latitude: Double? = null
    var longitude: Double? = null

    var userLatLng: LatLng? = null
    var trackerLatLng: LatLng? = null

    val TAG = "tagLog"
    private lateinit var mGoogleApiClient: GoogleApiClient
    private var mLocationManager: LocationManager? = null
    lateinit var mLocation: Location
    private var mLocationRequest: LocationRequest? = null
    private val listener: com.google.android.gms.location.LocationListener? = null
    private val UPDATE_INTERVAL = (1000 * 60 * 3).toLong()  /* 10 secs */
    private val FASTEST_INTERVAL: Long = 1000 * 30 /* 30 sec */

    lateinit var locationManager: LocationManager


    override fun onConnected(p0: Bundle?) {

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            return;
        }
        startLocationUpdates();

        var fusedLocationProviderClient:
                FusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        fusedLocationProviderClient.getLastLocation()
                .addOnSuccessListener(this, OnSuccessListener<Location> { location ->
                    // Got last known location. In some rare situations this can be null.
                    if (location != null) {
                        // Logic to handle location object
                        mLocation = location;
                        /*txt_latitude.setText("" + mLocation.latitude)
                        txt_longitude.setText("" + mLocation.longitude)*/
                    }
                })
    }

    override fun onConnectionSuspended(p0: Int) {


        Log.i(TAG, "Connection Suspended");
        mGoogleApiClient.connect();
    }

    override fun onConnectionFailed(connectionResult: ConnectionResult) {
        //To change body of created functions use File | Settings | File Templates.
        Log.i(TAG, "Connection failed. Error: " + connectionResult.getErrorCode());
        Log.i(TAG, "Connection failed. Error2: " + connectionResult.errorMessage);
    }

    override fun onLocationChanged(location: Location?) {
        //To change body of created functions use File | Settings | File Templates.

        var msg = "Updated Location: Latitude " + location?.longitude.toString() + location?.longitude;
        // txt_latitude.setText(""+location.latitude);
        //   txt_longitude.setText(""+location.longitude);

        latitude = location?.latitude
        longitude = location?.longitude
        trackerLatLng = LatLng(latitude!!, longitude!!)

        address = getAddress(LatLng(latitude!!, longitude!!))

        /* Thread({

              var countryName = ""
              var state = ""
              var town = ""
              var locality = ""
              var zip = ""



              try {
                  val gcd = Geocoder(this@MapsActivity, Locale.getDefault())
                  var addresses: List<Address>? = null
                  addresses = gcd.getFromLocation(latitude!!, longitude!!, 1)
                  if (addresses!!.size > 0) {
                      countryName = addresses[0].countryName
                      state = addresses[0].adminArea
                      town = addresses[0].subAdminArea

                      locality = addresses[0].locality
                      zip = addresses[0].postalCode
                  }
                  address= "$countryName $state $town $locality $zip"

                  if(type.equals("3",true))
                  {
                      // Trucker
                      if ( intentType.equals("active",true) )
                      {
                          trackerLatLng = LatLng(latitude!!, longitude!!)


                          if(NetworkUtil.isConnected(this@MapsActivity) && latitude !=null){
                              UpdateLocatioAsync()
                                      .execute("http://triptoe.pearnode.com/api_mobile/api/transport_position_update",tranId,latitude.toString(),longitude.toString(),address)

                          }
                          else{
                              Toast.makeText(this, "Please Check your internet connection and gps provider", Toast.LENGTH_LONG).show();
                          }
                      }
                  }


              } catch (e: Exception) {
                  e.printStackTrace()
                 // address= ""
                  Toast.makeText(this, "Please Check your internet connection and gps provider", Toast.LENGTH_LONG).show();
              }




          }).start()*/


        //   Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();

        //   if(longitude ==null){}

        if (type.equals("3", true)) {
            // Trucker
            if (intentType.equals("active", true)) {
                try {
                    trackerLatLng = LatLng(latitude!!, longitude!!)


                    if (NetworkUtil.isConnected(this@MapsActivity) && latitude != null) {
                        UpdateLocatioAsync()
                                .execute("http://triptoe.pearnode.com/api_mobile/api/transport_position_update", tranId, latitude.toString(), longitude.toString(), address)

                    } else {
                        Toast.makeText(this, "Please Check your internet connection and gps provider", Toast.LENGTH_LONG).show();
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

        }


        if (intentType.equals("active", true)) {
            if (NetworkUtil.isConnected(this@MapsActivity) && latitude != null) {

                TransportDetailAsync().execute("http://triptoe.pearnode.com/api_mobile/api/transport_details", tranId)
            } else {
                Toast.makeText(this, "Please Check your internet connection and gps provider", Toast.LENGTH_SHORT).show();
            }
        }

    }

    protected fun startLocationUpdates() {

        // Create the location request
        mLocationRequest = LocationRequest.create()
                .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
                .setInterval(UPDATE_INTERVAL)
                .setFastestInterval(FASTEST_INTERVAL);
        // Request location updates
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient,
                mLocationRequest, this);
    }

    override fun onStart() {
        super.onStart();
        if (mGoogleApiClient != null) {
            mGoogleApiClient.connect();
        }
    }

    override fun onStop() {
        super.onStop();
        if (mGoogleApiClient.isConnected()) {
            mGoogleApiClient.disconnect();
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_maps)
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.

        val mapFragment = supportFragmentManager
                .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this@MapsActivity)

        //   MultiDex.install(this)

        mGoogleApiClient = GoogleApiClient.Builder(this@MapsActivity)
                .addConnectionCallbacks(this@MapsActivity)
                .addOnConnectionFailedListener(this@MapsActivity)
                .addApi(LocationServices.API)
                .build()

        mLocationManager = this@MapsActivity.getSystemService(Context.LOCATION_SERVICE) as LocationManager




        cmpltLay.setOnClickListener(View.OnClickListener
        {
            /*UserConfirmedAsync().
                           execute("http://triptoe.pearnode.com/api_mobile/api/submitStatus","id, user_feedback")*/
            createDialog()
        })


        emgncyLay.setOnClickListener(View.OnClickListener { Toast.makeText(this, "We are working on it" as String, Toast.LENGTH_LONG).show() })

        updateLocLay.setOnClickListener(View.OnClickListener {

            if (NetworkUtil.isConnected(this@MapsActivity) && latitude != null) {

                UpdateLocatioAsync()
                        .execute("http://triptoe.pearnode.com/api_mobile/api/transport_position_with_flag_update", tranId, latitude.toString(), longitude.toString(), address)

            } else {
                Toast.makeText(this, "Please Check your internet connection and gps provider", Toast.LENGTH_SHORT).show();
            }

        })


        val editor = getSharedPreferences("truck", Context.MODE_PRIVATE)
        type = editor.getString("type", "type")
        userId = editor.getString("userId", "userId")

        val intentGet = getIntent()
        tranId = intentGet.getStringExtra("trsnId")
        intentType = intentGet.getStringExtra("type")
        //  intentType=intentGet.getStringExtra("type")


        if (type.equals("3", true)) {
            // Trucker
            //  cmpltLay.visibility=View.GONE

            if (intentType.equals("active", true)) {
                updateLocLay.visibility = View.VISIBLE
                emgncyLay.visibility = View.VISIBLE

                //   trackerLatLng = LatLng(latitude!!, longitude!!)

                /*  var help :Help= Help()
                  address = help.getAddress(LatLng(latitude!!,longitude!!))*/
                //      UpdateLocatioAsync().execute("http://triptoe.pearnode.com/api_mobile/api/transport_position_update",tranId,latitude.toString(),longitude.toString(),address)
            }

         //   if (intentType.equals("pending", true)) {
                updateLayCmplt.visibility = View.VISIBLE

                updateLayCmplt.setOnClickListener(View.OnClickListener
                {

                    if (NetworkUtil.isConnected(this@MapsActivity)) {

                        if (latitude != null)
                            TruckerConfirmedAsync().execute("http://triptoe.pearnode.com/api_mobile/api/deliveryStatus", tranId, "" + latitude, "" + longitude)
                        else
                            Toast.makeText(this, "please wait for your location update", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "Please Check your internet connection", Toast.LENGTH_SHORT).show();
                    }
                })

          /*  } else {
                //   pendingTrnsLay.visibility=View.GONE
            }*/

        } else if (type.equals("2", true)) {
            //  emgncyLay.visibility=View.GONE

            //  cmpltLay.visibility=View.VISIBLE

            if (intentType.equals("active", true))
                cmpltLay.visibility = View.VISIBLE
        }

        emgncyLay.setOnClickListener(View.OnClickListener {
            val intent = Intent(this@MapsActivity, Emergency::class.java)
            intent.putExtra("id", tranId)
            startActivity(intent)
        })

        var pause :Boolean=true

        pauseLay.setOnClickListener(View.OnClickListener {
            if(pause) {
                pauseTxt.text = "Start"
                pause=false
            }
            else {
                pauseTxt.text = "Pause"
                pause=true
            }
        })

        //   TransportDetailAsync().execute("http://triptoe.pearnode.com/api_mobile/api/transport_details",tranId)
    }

    fun createDialog() {
        val mDialogView = LayoutInflater.from(this).inflate(R.layout.dialog_submit_transport, null)
        //AlertDialogBuilder
        val mBuilder = AlertDialog.Builder(this)
                .setView(mDialogView)
        // .setTitle("Submit Form")
        //show dialog
        val mAlertDialog = mBuilder.show()
        //login button click of custom layout
        mDialogView.submitBtn.setOnClickListener {
            //dismiss dialog
            //   val msg = mDialogView.descEdt.text.toString()

            if (NetworkUtil.isConnected(this@MapsActivity)) {

                UserConfirmedAsync().execute("http://triptoe.pearnode.com/api_mobile/api/submitStatus", tranId)
            } else {
                Toast.makeText(this, "Please Check your internet connection", Toast.LENGTH_SHORT).show();
            }
            mAlertDialog.dismiss()
            //get text from EditTexts of custom layout


            //set the input text in TextView
            //   mainInfoTv.setText("Name:"+ name +"\nEmail: "+ email +"\nPassword: "+ password)
        }
        //cancel button click of custom layout
        mDialogView.canCeltBtn.setOnClickListener {
            //dismiss dialog
            mAlertDialog.dismiss()
        }
    }

    inner class TransportDetailAsync : AsyncTask<String, String, String>() {


        //  internal var pdLoading: ProgressDialog? = null
        override fun onPreExecute() {
            super.onPreExecute()
/*
                     pdLoading = ProgressDialog(this@MapsActivity);
                       pdLoading?.setMessage("\tLoding location...");
                     pdLoading?.setCancelable(false);
                    pdLoading?.show();*/

            Toast.makeText(this@MapsActivity, "Location updating...", Toast.LENGTH_SHORT).show();

        }

        override fun doInBackground(vararg urls: String): String? {

            var connection: HttpURLConnection? = null
            var reader: BufferedReader? = null

            try {
                val url = URL(urls[0])
                connection = url.openConnection() as HttpURLConnection

                connection.readTimeout = 10000
                connection.connectTimeout = 15000
                connection.requestMethod = "POST"
                connection.doInput = true
                connection.doOutput = true

                val builder = Uri.Builder()

                        .appendQueryParameter("id", urls[1])

                // .appendQueryParameter("device_id", device_id)


                val query = builder.build().query
                val os = connection.outputStream
                val writer = BufferedWriter(
                        OutputStreamWriter(os))
                writer.write(query)
                writer.flush()
                writer.close()
                os.close()
                connection.connect()

                val stream = connection.inputStream
                reader = BufferedReader(InputStreamReader(stream))

                var line: String? = ""
                val buffer = StringBuffer()

                /* while ((line = reader.readLine()) != null) {
                     buffer.append(line)
                 }*/

                do {
                    line = reader.readLine()

                    if (line == null)

                        break
                    else
                        buffer.append(line)
                    //  println(line)

                }
                // while (true)
                while (line == null)

                val finaljson = buffer.toString()

                val parentobjt = JSONObject(finaljson)

                //               ShippingAddressModel shippingAddressModel=new ShippingAddressModel();
                //
                //               shippingAddressModel.setMsg(parentobjt.getString("msg"));
                //               shippingAddressModel.setStatus(parentobjt.getBoolean("status"));

                Log.d("jsonLogIn2", "" + parentobjt)
                return finaljson

            } catch (e: MalformedURLException) {
                e.printStackTrace()
            } catch (e: IOException) {
                e.printStackTrace()
            } catch (e: JSONException) {
                e.printStackTrace()
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                // pdLoading?.dismiss()
            }


            return null
        }

        override fun onPostExecute(response: String) {
            super.onPostExecute(response)

            try {

                val parentobjt = JSONObject(response)
                Log.d("jsonDetails", "" + parentobjt)


                //Toast.makeText(Login.this,status+result+msg,Toast.LENGTH_LONG).show();


                var innerObj2 = parentobjt.getString("end_location")   //User
                var jObjUser = JSONObject(innerObj2)

                var lat = jObjUser.getString("location_lat").toDouble()
                var lng = jObjUser.getString("location_long").toDouble()

                userLatLng = LatLng(lat, lng)


                var innerObj = parentobjt.getString("start_location")  // Trucker
                var jObjTrucker = JSONObject(innerObj)

                var startLat = jObjTrucker.getString("location_lat").toDouble()
                var startlong = jObjTrucker.getString("location_long").toDouble()


                var lat2 = parentobjt.getString("last_lat").toDouble()
                var lng2 = parentobjt.getString("last_long").toDouble()
                trackerLatLng = LatLng(lat2, lng2)  //Trucker current


                //     Log.d("latLngChk",""+trackerLatLng+"  "+userLatLng)


                //  GetDirection( getDirectionsUrl(userLatLng,trackerLatLng)).execute()


                //getDirectionsUrl(trackerLatLng,userLatLng)

                mMap.clear()
                GetDirection(getDirectionsUrl(LatLng(startLat, startlong)!!, trackerLatLng)).execute()

                mMap.addMarker(MarkerOptions().position(LatLng(startLat, startlong)!!).title(jObjTrucker.getString("address")))

                // mMap.addMarker(MarkerOptions().position(userLatLng!!).title(jObjUser.getString("address")))
                markerChng = mMap.addMarker(MarkerOptions()
                        .position(trackerLatLng!!)
                        .title("Last position"))

                //   mMap.addMarker(MarkerOptions().position(userLatLng!!).title(jObjUser.getString("address")))  //Last address


                if (breaker == true) {
                    mMap.moveCamera(CameraUpdateFactory.newLatLng(trackerLatLng))
                    mMap.animateCamera(CameraUpdateFactory.zoomTo(14f))



                    breaker = false
                }


                if (intentType.equals("active", true)) {
                    if (markerChng != null) {
                        //   markerChng!!.remove()

                        markerChng = mMap.addMarker(MarkerOptions()
                                .position(trackerLatLng!!)
                                .title("Last position"))
                    } else {
                        markerChng = mMap.addMarker(MarkerOptions()
                                .position(trackerLatLng!!)
                                .title("Last position"))
                    }

                } else {


                }


                /*  val downloadTask = DownloadTask()
                  var url=getDirectionsUrl(userLatLng!!,trackerLatLng!!)

                  // Start downloading json data from Google Directions API
                  downloadTask.execute(url)*/


                /*   val sydney1 = LatLng(22.779200, 88.367870)
                   val sydney2 = LatLng(22.564056, 88.353853)*/

                //   GetDirection( getDirectionsUrl(sydney,sydney2)).execute()


                /*   mMap.addMarker(MarkerOptions().position(sydney1).title("Marker in Sydney"))
                   mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney1))*/

            } catch (e: JSONException) {
                e.printStackTrace()
            } catch (ex: Exception) {
                ex.printStackTrace()
                Log.d("expst", " Nullpointer exception")
            }

        }
    }

    inner class UpdateLocatioAsync : AsyncTask<String, String, String>() {


        internal var pdLoading: ProgressDialog? = null
        override fun onPreExecute() {
            super.onPreExecute()

            pdLoading = ProgressDialog(this@MapsActivity);
            pdLoading?.setMessage("\tUpdating your location...");
            pdLoading?.setCancelable(false);
            pdLoading?.show();

        }

        override fun doInBackground(vararg urls: String): String? {

            var connection: HttpURLConnection? = null
            var reader: BufferedReader? = null

            try {
                val url = URL(urls[0])
                connection = url.openConnection() as HttpURLConnection

                connection.readTimeout = 10000
                connection.connectTimeout = 15000
                connection.requestMethod = "POST"
                connection.doInput = true
                connection.doOutput = true

                val builder = Uri.Builder()

                        .appendQueryParameter("id", urls[1])
                        .appendQueryParameter("current_lat", urls[2])
                        .appendQueryParameter("current_long", urls[3])
                        .appendQueryParameter("current_address", urls[4])

                // .appendQueryParameter("device_id", device_id)


                val query = builder.build().query
                val os = connection.outputStream
                val writer = BufferedWriter(
                        OutputStreamWriter(os))
                writer.write(query)
                writer.flush()
                writer.close()
                os.close()
                connection.connect()

                val stream = connection.inputStream
                reader = BufferedReader(InputStreamReader(stream))

                var line: String? = ""
                val buffer = StringBuffer()

                /* while ((line = reader.readLine()) != null) {
                     buffer.append(line)
                 }*/

                do {
                    line = reader.readLine()

                    if (line == null)

                        break
                    else
                        buffer.append(line)
                    //  println(line)

                }
                // while (true)
                while (line == null)

                val finaljson = buffer.toString()

                val parentobjt = JSONObject(finaljson)

                //               ShippingAddressModel shippingAddressModel=new ShippingAddressModel();
                //
                //               shippingAddressModel.setMsg(parentobjt.getString("msg"));
                //               shippingAddressModel.setStatus(parentobjt.getBoolean("status"));

                Log.d("jsonLogIn2", "" + parentobjt)


                return finaljson

            } catch (e: MalformedURLException) {
                e.printStackTrace()
            } catch (e: IOException) {
                e.printStackTrace()
            } catch (e: JSONException) {
                e.printStackTrace()
            } finally {
                pdLoading?.dismiss()
            }


            return null
        }

        override fun onPostExecute(response: String) {
            super.onPostExecute(response)

            try {

                val parentobjt = JSONObject(response)
                Log.d("jsonDetails", "" + parentobjt)


                //Toast.makeText(Login.this,status+result+msg,Toast.LENGTH_LONG).show();

                // Trucker

                /*
                 var innerObj2  =parentobjt.getString("end_location")   //User
                 var jObjUser = JSONObject(innerObj2)

                 userLatLng = LatLng(jObjUser.getString("location_lat")
                         as Double,jObjUser.getString("location_long") as Double)


                 if (!type.equals("3", true))
                 {
                     var innerObj  =parentobjt.getString("start_location")
                     var jObjTrucker = JSONObject(innerObj)
                     trackerLatLng = LatLng(jObjTrucker.getString("location_lat")      //Trucker
                             as Double,jObjTrucker.getString("location_long") as Double)
                 }

                 GetDirection( getDirectionsUrl(userLatLng,trackerLatLng)).execute()*/

                if (parentobjt.getString("type").equals("success", true)) {
                    Toast.makeText(this@MapsActivity, "Location updated", Toast.LENGTH_SHORT).show();
                }


            } catch (e: JSONException) {
                e.printStackTrace()
            } catch (ex: Exception) {
                ex.printStackTrace()
                Log.d("expst", " Nullpointer exception")
            }

        }
    }

    inner class UserConfirmedAsync : AsyncTask<String, String, String>() {


        internal var pdLoading: ProgressDialog? = null
        override fun onPreExecute() {
            super.onPreExecute()

            pdLoading = ProgressDialog(this@MapsActivity);
            pdLoading?.setMessage("\tSubmiting...");
            pdLoading?.setCancelable(false);
            pdLoading?.show();

        }

        override fun doInBackground(vararg urls: String): String? {

            var connection: HttpURLConnection? = null
            var reader: BufferedReader? = null

            try {
                val url = URL(urls[0])
                connection = url.openConnection() as HttpURLConnection

                connection.readTimeout = 10000
                connection.connectTimeout = 15000
                connection.requestMethod = "POST"
                connection.doInput = true
                connection.doOutput = true

                val builder = Uri.Builder()

                        .appendQueryParameter("id", urls[1])
                // .appendQueryParameter("user_feedback", urls[2])

                // .appendQueryParameter("device_id", device_id)


                val query = builder.build().query
                val os = connection.outputStream
                val writer = BufferedWriter(
                        OutputStreamWriter(os))
                writer.write(query)
                writer.flush()
                writer.close()
                os.close()
                connection.connect()

                val stream = connection.inputStream
                reader = BufferedReader(InputStreamReader(stream))

                var line: String? = ""
                val buffer = StringBuffer()

                /* while ((line = reader.readLine()) != null) {
                     buffer.append(line)
                 }*/

                do {
                    line = reader.readLine()

                    if (line == null)

                        break
                    else
                        buffer.append(line)
                    //  println(line)

                }
                // while (true)
                while (line == null)

                val finaljson = buffer.toString()

                val parentobjt = JSONObject(finaljson)

                //               ShippingAddressModel shippingAddressModel=new ShippingAddressModel();
                //
                //               shippingAddressModel.setMsg(parentobjt.getString("msg"));
                //               shippingAddressModel.setStatus(parentobjt.getBoolean("status"));

                Log.d("jsonLogIn2", "" + parentobjt)
                return finaljson

            } catch (e: MalformedURLException) {
                e.printStackTrace()
            } catch (e: IOException) {
                e.printStackTrace()
            } catch (e: JSONException) {
                e.printStackTrace()
            } finally {
                pdLoading?.dismiss()
            }


            return null
        }

        override fun onPostExecute(response: String) {
            super.onPostExecute(response)

            try {

                val parentobjt = JSONObject(response)
                var msg = parentobjt.getString("text");
                Toast.makeText(this@MapsActivity, msg, Toast.LENGTH_LONG).show();
                //   Toast.makeText(this@MapsActivity,msg,LEN)
                /* Log.d("jsonDetails",""+parentobjt)

                 //Toast.makeText(Login.this,status+result+msg,Toast.LENGTH_LONG).show();


                 // Trucker
                 var innerObj2  =parentobjt.getString("end_location")   //User
                 var jObjUser = JSONObject(innerObj2)

                 userLatLng = LatLng(jObjUser.getString("location_lat")
                         as Double,jObjUser.getString("location_long") as Double)


                 if (!type.equals("3", true))
                 {
                     var innerObj  =parentobjt.getString("start_location")
                     var jObjTrucker = JSONObject(innerObj)
                     trackerLatLng = LatLng(jObjTrucker.getString("location_lat")      //Trucker
                             as Double,jObjTrucker.getString("location_long") as Double)
                 }

                 GetDirection( getDirectionsUrl(userLatLng,trackerLatLng)).execute()
 */


            } catch (e: JSONException) {
                e.printStackTrace()
            } catch (ex: Exception) {
                ex.printStackTrace()
                Log.d("expst", " Nullpointer exception")
            }

        }
    }

    inner class TruckerConfirmedAsync : AsyncTask<String, String, String>() {


        internal var pdLoading: ProgressDialog? = null
        override fun onPreExecute() {
            super.onPreExecute()

            pdLoading = ProgressDialog(this@MapsActivity);
            pdLoading?.setMessage("\tSubmiting...");
            pdLoading?.setCancelable(false);
            pdLoading?.show();

        }

        override fun doInBackground(vararg urls: String): String? {

            var connection: HttpURLConnection? = null
            var reader: BufferedReader? = null

            try {
                val url = URL(urls[0])
                connection = url.openConnection() as HttpURLConnection

                connection.readTimeout = 10000
                connection.connectTimeout = 15000
                connection.requestMethod = "POST"
                connection.doInput = true
                connection.doOutput = true

                val builder = Uri.Builder()

                        .appendQueryParameter("id", urls[1])
                        .appendQueryParameter("current_lat", urls[2])
                        .appendQueryParameter("current_long", urls[3])
                // .appendQueryParameter("user_feedback", urls[2])

                // .appendQueryParameter("device_id", device_id)


                val query = builder.build().query
                val os = connection.outputStream
                val writer = BufferedWriter(
                        OutputStreamWriter(os))
                writer.write(query)
                writer.flush()
                writer.close()
                os.close()
                connection.connect()

                val stream = connection.inputStream
                reader = BufferedReader(InputStreamReader(stream))

                var line: String? = ""
                val buffer = StringBuffer()

                /* while ((line = reader.readLine()) != null) {
                     buffer.append(line)
                 }*/

                do {
                    line = reader.readLine()

                    if (line == null)

                        break
                    else
                        buffer.append(line)
                    //  println(line)

                }
                // while (true)
                while (line == null)

                val finaljson = buffer.toString()

                val parentobjt = JSONObject(finaljson)

                //               ShippingAddressModel shippingAddressModel=new ShippingAddressModel();
                //
                //               shippingAddressModel.setMsg(parentobjt.getString("msg"));
                //               shippingAddressModel.setStatus(parentobjt.getBoolean("status"));

                Log.d("jsonLogIn2", "" + parentobjt)
                return finaljson

            } catch (e: MalformedURLException) {
                e.printStackTrace()
            } catch (e: IOException) {
                e.printStackTrace()
            } catch (e: JSONException) {
                e.printStackTrace()
            } finally {
                pdLoading?.dismiss()
            }


            return null
        }

        override fun onPostExecute(response: String) {
            super.onPostExecute(response)

            try {

                val parentobjt = JSONObject(response)
                var msg = parentobjt.getString("text");
                Toast.makeText(this@MapsActivity, msg, Toast.LENGTH_LONG).show();
                if(parentobjt.getString("type").equals("success"))
                {
                    var intent:Intent=Intent(this@MapsActivity,Create::class.java)
                    startActivity(intent)
                    finish()
                }

                /* val intent = Intent(this@MapsActivity, HomeActivity::class.java)
                 startActivity(intent)*/

                //   Toast.makeText(this@MapsActivity,msg,LEN)
                /* Log.d("jsonDetails",""+parentobjt)

                 //Toast.makeText(Login.this,status+result+msg,Toast.LENGTH_LONG).show();


                 // Trucker
                 var innerObj2  =parentobjt.getString("end_location")   //User
                 var jObjUser = JSONObject(innerObj2)

                 userLatLng = LatLng(jObjUser.getString("location_lat")
                         as Double,jObjUser.getString("location_long") as Double)


                 if (!type.equals("3", true))
                 {
                     var innerObj  =parentobjt.getString("start_location")
                     var jObjTrucker = JSONObject(innerObj)
                     trackerLatLng = LatLng(jObjTrucker.getString("location_lat")      //Trucker
                             as Double,jObjTrucker.getString("location_long") as Double)
                 }

                 GetDirection( getDirectionsUrl(userLatLng,trackerLatLng)).execute()
 */


            } catch (e: JSONException) {
                e.printStackTrace()
            } catch (ex: Exception) {
                ex.printStackTrace()
                Log.d("expst", " Nullpointer exception")
            }


        }
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @SuppressLint("MissingPermission")
    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        mMap.setMyLocationEnabled(true);

        // Add a marker in Sydney and move the camera
        /*  val sydney = LatLng(22.779200, 88.367870)
          val sydney2 = LatLng(22.564056, 88.353853)
          mMap.addMarker(MarkerOptions().position(sydney).title("Marker in Sydney"))
          mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney))*/

        //   GetDirection( getDirectionsUrl(sydney,sydney2)).execute()

        if (NetworkUtil.isConnected(this@MapsActivity)) {

            TransportDetailAsync().execute("http://triptoe.pearnode.com/api_mobile/api/transport_details", tranId)
        } else {
            Toast.makeText(this, "Please Check your internet connection", Toast.LENGTH_SHORT).show();
        }

    }


    fun getDirectionsUrl(origin: LatLng?, dest: LatLng?): String {
        try {


            // Origin of route
            var str_origin = "origin=" + origin?.latitude + "," + origin?.longitude;

            // Destination of route
            var str_dest = "destination=" + dest?.latitude + "," + dest?.longitude;


            // Sensor enabled
            var sensor = "sensor=false";
            val key = "key=AIzaSyCalq1X5G_MhRRalG_OtdUehaSoaL7y7gc"

            // Building the parameters to the web service
            var parameters = str_origin + "&" + str_dest + "&" + sensor + "&" + key;

            // Output format
            var output = "json";

            // Building the url to the web service
            var url = "https://maps.googleapis.com/maps/api/directions/" + output + "?" + parameters;

            return url;
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this@MapsActivity, "unable to find  path", Toast.LENGTH_SHORT).show();
        }
        return "";
    }


    private inner class GetDirection(val url: String) : AsyncTask<Void, Void, List<List<LatLng>>>() {
        override fun doInBackground(vararg params: Void?): List<List<LatLng>> {
            val client = OkHttpClient()
            val request = Request.Builder().url(url).build()
            val response = client.newCall(request).execute()
            val data = response.body()!!.string()
            Log.d("GoogleMap", " data : $data")
            val result = ArrayList<List<LatLng>>()
            try {
                val respObj = Gson().fromJson(data, GoogleMapDTO::class.java)

                val path = ArrayList<LatLng>()

                for (i in 0..(respObj.routes[0].legs[0].steps.size - 1)) //............................. Index out of bound
                {
//                    val startLatLng = LatLng(respObj.routes[0].legs[0].steps[i].start_location.lat.toDouble()
//                            ,respObj.routes[0].legs[0].steps[i].start_location.lng.toDouble())
//                    path.add(startLatLng)
//                    val endLatLng = LatLng(respObj.routes[0].legs[0].steps[i].end_location.lat.toDouble()
//                            ,respObj.routes[0].legs[0].steps[i].end_location.lng.toDouble())
                    path.addAll(decodePolyline(respObj.routes[0].legs[0].steps[i].polyline.points))
                }
                result.add(path)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            return result
        }

        override fun onPostExecute(result: List<List<LatLng>>) {

            try {


                val lineoption = PolylineOptions()
                for (i in result.indices) {
                    lineoption.addAll(result[i])
                    lineoption.width(10f)
                    lineoption.color(Color.BLUE)
                    lineoption.geodesic(true)
                }
                mMap.addPolyline(lineoption)
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(this@MapsActivity, "unable to find  path", Toast.LENGTH_SHORT).show();
            }
        }
    }

    fun decodePolyline(encoded: String): List<LatLng> {

        val poly = ArrayList<LatLng>()

        try {

            var index = 0
            val len = encoded.length
            var lat = 0
            var lng = 0

            while (index < len) {
                var b: Int
                var shift = 0
                var result = 0
                do {
                    b = encoded[index++].toInt() - 63
                    result = result or (b and 0x1f shl shift)
                    shift += 5
                } while (b >= 0x20)
                val dlat = if (result and 1 != 0) (result shr 1).inv() else result shr 1
                lat += dlat

                shift = 0
                result = 0
                do {
                    b = encoded[index++].toInt() - 63
                    result = result or (b and 0x1f shl shift)
                    shift += 5
                } while (b >= 0x20)
                val dlng = if (result and 1 != 0) (result shr 1).inv() else result shr 1
                lng += dlng

                val latLng = LatLng((lat.toDouble() / 1E5), (lng.toDouble() / 1E5))
                poly.add(latLng)
            }

            return poly
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this@MapsActivity, "unable to find  path", Toast.LENGTH_SHORT).show();
        }
        return poly
    }


    fun getAddress(latLng: LatLng): String {
        var countryName = ""
        var state = ""
        var town = ""
        var locality = ""
        var zip = ""



        try {
            val gcd = Geocoder(this@MapsActivity, Locale.getDefault())
            var addresses: List<Address>? = null
            addresses = gcd.getFromLocation(latLng.latitude, latLng.longitude, 1)
            if (addresses!!.size > 0) {
                countryName = addresses[0].countryName
                state = addresses[0].adminArea
                town = addresses[0].subAdminArea

                locality = addresses[0].locality
                zip = addresses[0].postalCode
            }
        } catch (e: Exception) {
            e.printStackTrace()
            return "unable to find address"
        }


        return "$countryName $state $town $locality $zip"
    }


    override fun onBackPressed() {
        super.onBackPressed()
        val intent = Intent(this@MapsActivity, ActiveTripsActivity::class.java)
        startActivity(intent)
        finish()
    }

}
