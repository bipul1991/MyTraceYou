package com.pearnode.blaze.triptoe

/*import kotlinx.android.synthetic.main.activity_completed.**/

import android.Manifest
import android.app.DatePickerDialog
import android.app.ProgressDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.AsyncTask
import android.os.Bundle
import android.support.multidex.MultiDex
import android.support.v4.app.ActivityCompat
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.api.GoogleApiClient
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.tasks.OnSuccessListener
import com.pearnode.blaze.triptoe.utils.NetworkUtil
import kotlinx.android.synthetic.main.activity_create.*
import org.json.JSONException
import org.json.JSONObject
import java.io.*
import java.net.HttpURLConnection
import java.net.MalformedURLException
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

class Create : AppCompatActivity(), GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener, com.google.android.gms.location.LocationListener {

    var address = "my addreess"
    var sendOrdNo = ""

    var latitude: Double? = null
    var longitude: Double? = null
    var username: String? = null
    var userId: String? = null
    var userType: String? = null

    var orderNumList: ArrayList<String>? = null

    val TAG = "MainActivity"
    private lateinit var mGoogleApiClient: GoogleApiClient
    private var mLocationManager: LocationManager? = null
    lateinit var mLocation: Location
    private var mLocationRequest: LocationRequest? = null
    private val listener: com.google.android.gms.location.LocationListener? = null
    private val UPDATE_INTERVAL = (1000 * 60 * 3).toLong()  /* 10 secs */
    private val FASTEST_INTERVAL: Long = 1000 * 60 * 10 /* 30 sec */

    lateinit var locationManager: LocationManager

    // trcNumSpnr
    val truckNumsArray = arrayOf("OD02BG4511", "OD02AX8879", "OD05MI3455", "OD06PA9903")
    // Date and time
    var button_date: Button? = null
    var button_timeClk: Button? = null
    var textview_date: TextView? = null
    var text_view_timeClk: TextView? = null
    var cal = Calendar.getInstance()

    override fun onStart() {
        super.onStart();
        if (mGoogleApiClient != null) {
            mGoogleApiClient.connect();
        }
    }

    override fun onStop() {
        super.onStop();
        if (mGoogleApiClient.isConnected()) {
            mGoogleApiClient.disconnect();
        }
    }

    override fun onConnected(p0: Bundle?) {
        //To change body of created functions use File | Settings | File Templates.

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            return;
        }


        startLocationUpdates();

        var fusedLocationProviderClient:
                FusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        fusedLocationProviderClient.getLastLocation()
                .addOnSuccessListener(this, OnSuccessListener<Location> { location ->
                    // Got last known location. In some rare situations this can be null.
                    if (location != null) {
                        // Logic to handle location object
                        mLocation = location;
                        /*txt_latitude.setText("" + mLocation.latitude)
                        txt_longitude.setText("" + mLocation.longitude)*/
                    }
                })
    }

    override fun onConnectionSuspended(p0: Int) {
        //To change body of created functions use File | Settings | File Templates.

        Log.i(TAG, "Connection Suspended");
        mGoogleApiClient.connect();
    }

    override fun onConnectionFailed(connectionResult: ConnectionResult) {
        //To change body of created functions use File | Settings | File Templates.
        Log.i(TAG, "Connection failed. Error: " + connectionResult.getErrorCode());
        Log.i(TAG, "Connection failed. Error2: " + connectionResult.errorMessage);
    }

    override fun onLocationChanged(location: Location?) {
        //To change body of created functions use File | Settings | File Templates.

        var msg = "Updated Location: Latitude " + location?.longitude.toString() + location?.longitude;
        // txt_latitude.setText(""+location.latitude);
        //   txt_longitude.setText(""+location.longitude);

        latitude = location?.latitude
        longitude = location?.longitude
        //    Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();

        //  var help : Help = Help()
        //   address = help.getAddress(LatLng(latitude!!,longitude!!))

        if (latitude != null)
            address = getAddress(LatLng(latitude!!, longitude!!))!!
        else
            address = "updating"


    }

    private fun isLocationEnabled(): Boolean {
        locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) || locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
    }

    protected fun startLocationUpdates() {

        // Create the location request
        mLocationRequest = LocationRequest.create()
                .setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
                .setInterval(UPDATE_INTERVAL)
                .setFastestInterval(FASTEST_INTERVAL);
        // Request location updates
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient,
                mLocationRequest, this);
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create)

        /* setTitle("TRIPTOE");
         this.actionBar.setIcon(R.drawable.logo);
 */
        recyclerView.layoutManager = LinearLayoutManager(this)
        setTheme(R.style.AppTheme);
        MultiDex.install(this@Create)

        mGoogleApiClient = GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .build()

        mLocationManager = this.getSystemService(Context.LOCATION_SERVICE) as LocationManager

        trcNumSpnr.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, truckNumsArray)
        var truckNm = ""

        trcNumSpnr.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {


                truckNm = truckNumsArray[p2]
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {

            }
        }


        if (NetworkUtil.isConnected(this@Create) && isLocationEnabled()) {
            OrderIdAsync().execute("http://triptoe.pearnode.com/api_mobile/api/new_order_no")
        } else {
            Toast.makeText(this, "Please Check your internet connection and gps provider", Toast.LENGTH_SHORT).show();
        }

        val editor = getSharedPreferences("truck", Context.MODE_PRIVATE)
        username = editor.getString("username", "username")
        userType = editor.getString("type", "username")
        userId = editor.getString("userId", "username")

        if (!userType.equals("3", true)) {
            //Turucker
            if (isLocationEnabled()) {
                Toast.makeText(this, "Loc On", Toast.LENGTH_SHORT).show();
                val intent = Intent(this, ActiveTripsActivity::class.java)
                startActivity(intent);
                finish()
            } else {
                Toast.makeText(this, "Loc oFF", Toast.LENGTH_SHORT).show();

            }

        }

        textview_date = this.text_view_date_1
        text_view_timeClk = this.text_view_time
        button_date = this.button_date_1
        button_timeClk = this.button_time

        textview_date!!.text = "--/--/----"
        text_view_timeClk!!.text = "--/--"

        updateDateInView()

        getTime(text_view_timeClk!!, button_timeClk!!, this@Create)


        // val intentGet = getIntent();
        /*   var latitude1=intentGet.getStringExtra("lat").toDouble()
          var longitude1=intentGet.getStringExtra("lng").toDouble()*/


        /*  address = getAddress(LatLng(22.8488542, 88.66395910000006))

          latitude = 22.8488542
          longitude = 88.66395910000006*/


        /*   ordChk.setOnCheckedChangeListener { buttonView, isChecked ->
               if (isChecked) {
                   //Do Whatever you want in isChecked
                   orderNo=sendOrdNo
               }
               else
                   orderNo=""
           }*/

        submitBtn.setOnClickListener(View.OnClickListener {

            if (NetworkUtil.isConnected(this@Create) && isLocationEnabled() && !address.equals("updating") && latitude != null) {
                CreateTransport().execute("http://triptoe.pearnode.com/api_mobile/api/create_new_transport",
                        sendOrdNo, "" + latitude, "" + longitude, truckNm)
            } else {
                Toast.makeText(this, "Please Check your internet connection and gps provider", Toast.LENGTH_SHORT).show();
            }

        })

        activeBtn.setOnClickListener(View.OnClickListener {
            /* val intent = Intent(this, ActiveTripsActivity::class.java)
             startActivity(intent);*/
            if (isLocationEnabled()) {
                Toast.makeText(this, "Loc On", Toast.LENGTH_SHORT).show();
                val intent = Intent(this, ActiveTripsActivity::class.java)
                startActivity(intent);
                finish()
            } else {
                Toast.makeText(this, "Loc oFF", Toast.LENGTH_SHORT).show();

            }
        })


        // Date selector
        // get the references from layout file


        // create an OnDateSetListener
        val dateSetListener = object : DatePickerDialog.OnDateSetListener {
            override fun onDateSet(view: DatePicker, year: Int, monthOfYear: Int,
                                   dayOfMonth: Int) {
                cal.set(Calendar.YEAR, year)
                cal.set(Calendar.MONTH, monthOfYear)
                cal.set(Calendar.DAY_OF_MONTH, dayOfMonth)
                updateDateInView()
            }
        }

        // when you click on the button, show DatePickerDialog that is set with OnDateSetListener
        button_date!!.setOnClickListener(object : View.OnClickListener {
            override fun onClick(view: View) {
                DatePickerDialog(this@Create,
                        dateSetListener,
                        // set DatePickerDialog to point to today's date when it loads up
                        cal.get(Calendar.YEAR),
                        cal.get(Calendar.MONTH),
                        cal.get(Calendar.DAY_OF_MONTH)).show()
            }

        })

    }

    private fun updateDateInView() {
        // val myFormat = "MM/dd/yyyy" // mention the format you need
        val myFormat = "yyyy/MM/dd" // mention the format you need
        val sdf = SimpleDateFormat(myFormat, Locale.US)
        textview_date!!.text = sdf.format(cal.getTime())
    }

    inner class CreateTransport : AsyncTask<String, String, String>() {


        internal var pdLoading: ProgressDialog? = null
        override fun onPreExecute() {
            super.onPreExecute()

            pdLoading = ProgressDialog(this@Create);
            pdLoading?.setMessage("\tUploading please wait...");
            pdLoading?.setCancelable(false);
            pdLoading?.show();

        }

        override fun doInBackground(vararg urls: String): String? {

            var connection: HttpURLConnection? = null
            var reader: BufferedReader? = null

            try {
                val url = URL(urls[0])
                connection = url.openConnection() as HttpURLConnection

                connection.readTimeout = 10000
                connection.connectTimeout = 15000
                connection.requestMethod = "POST"
                connection.doInput = true
                connection.doOutput = true

                val builder = Uri.Builder()
                        // user_id, transporter_id, current_lat, current_long, current_address, transport_desc, created_by

                        .appendQueryParameter("user_id", urls[1])
                        .appendQueryParameter("transporter_id", userId)
                        .appendQueryParameter("current_lat", "" + urls[2])
                        .appendQueryParameter("current_long", "" + urls[3])
                        .appendQueryParameter("current_address", address)
                        // .appendQueryParameter("transport_desc", urls[2])
                        .appendQueryParameter("truck_no", urls[4])
                        .appendQueryParameter("created_by", username)


                val query = builder.build().query
                val os = connection.outputStream
                val writer = BufferedWriter(
                        OutputStreamWriter(os))
                writer.write(query)
                writer.flush()
                writer.close()
                os.close()
                connection.connect()

                val stream = connection.inputStream
                reader = BufferedReader(InputStreamReader(stream))

                var line: String? = ""
                val buffer = StringBuffer()

                /* while ((line = reader.readLine()) != null) {
                     buffer.append(line)
                 }*/

                do {
                    line = reader.readLine()

                    if (line == null)

                        break
                    else
                        buffer.append(line)
                    //  println(line)

                }
                // while (true)
                while (line == null)

                val finaljson = buffer.toString()

                val parentobjt = JSONObject(finaljson)

                //               ShippingAddressModel shippingAddressModel=new ShippingAddressModel();
                //
                //               shippingAddressModel.setMsg(parentobjt.getString("msg"));
                //               shippingAddressModel.setStatus(parentobjt.getBoolean("status"));

                return finaljson

            } catch (e: MalformedURLException) {
                e.printStackTrace()
            } catch (e: IOException) {
                e.printStackTrace()
            } catch (e: JSONException) {
                e.printStackTrace()
            } catch (ex: Exception) {
                ex.printStackTrace()
                Log.d("exExp", ex.message);
            } finally {
                pdLoading?.dismiss()
            }

            return null
        }

        override fun onPostExecute(response: String) {
            super.onPostExecute(response)

            try {

                val parentobjt = JSONObject(response)

                Log.d("jsonStatus", "" + parentobjt)
                //Toast.makeText(Login.this,status+result+msg,Toast.LENGTH_LONG).show();
                if (parentobjt.getString("type").equals("success", true)) {
                    Toast.makeText(this@Create, "Success", Toast.LENGTH_SHORT).show()
                    val intent = Intent(this@Create, ActiveTripsActivity::class.java)
                    startActivity(intent)
                } else {
                    Toast.makeText(this@Create, "" + parentobjt, Toast.LENGTH_SHORT).show()
                }

            } catch (e: JSONException) {
                e.printStackTrace()
            } catch (ex: Exception) {
                ex.printStackTrace()
                Log.d("expst", " Nullpointer exception")
            }

        }
    }

    /* fun getAddress(latLng: LatLng): String {
         var countryName = ""
         var state = ""
         var town = ""
         var locality = ""
         var zip = ""

         val gcd = Geocoder(this@Create, Locale.getDefault())
         var addresses: List<Address>? = null
         try {
             addresses = gcd.getFromLocation(latLng.latitude, latLng.longitude, 1)
         } catch (e: IOException) {
             e.printStackTrace()
         }

         if (addresses!!.size > 0) {
             countryName = addresses[0].countryName
             state = addresses[0].adminArea
             town = addresses[0].subAdminArea

             locality = addresses[0].locality
             zip = addresses[0].postalCode
         }
         return "$countryName $state $town $locality $zip"
     }*/

    inner class OrderIdAsync : AsyncTask<String, String, String>() {


        internal var pdLoading: ProgressDialog? = null
        override fun onPreExecute() {
            super.onPreExecute()

            pdLoading = ProgressDialog(this@Create);
            pdLoading?.setMessage("\tUploading please wait...");
            pdLoading?.setCancelable(false);
            pdLoading?.show();

        }

        override fun doInBackground(vararg urls: String): String? {

            var connection: HttpURLConnection? = null
            var reader: BufferedReader? = null

            try {
                val url = URL(urls[0])
                connection = url.openConnection() as HttpURLConnection

                connection.readTimeout = 10000
                connection.connectTimeout = 15000
                //    connection.requestMethod = "POST"
                connection.doInput = true
                connection.doOutput = true

                //  val builder = Uri.Builder()
                // user_id, transporter_id, current_lat, current_long, current_address, transport_desc, created_by

                // .appendQueryParameter("user_id", urls[1] )


                connection.connect()

                val stream = connection.inputStream
                reader = BufferedReader(InputStreamReader(stream))

                var line: String? = ""
                val buffer = StringBuffer()

                /* while ((line = reader.readLine()) != null) {
                     buffer.append(line)
                 }*/

                do {
                    line = reader.readLine()

                    if (line == null)

                        break
                    else
                        buffer.append(line)
                    //  println(line)

                }
                // while (true)
                while (line == null)

                val finaljson = buffer.toString()

                val parentobjt = JSONObject(finaljson)

                //               ShippingAddressModel shippingAddressModel=new ShippingAddressModel();
                //
                //               shippingAddressModel.setMsg(parentobjt.getString("msg"));
                //               shippingAddressModel.setStatus(parentobjt.getBoolean("status"));

                return finaljson

            } catch (e: MalformedURLException) {
                e.printStackTrace()
            } catch (e: IOException) {
                e.printStackTrace()
            } catch (e: JSONException) {
                e.printStackTrace()
            } catch (ex: Exception) {
                ex.printStackTrace()
                Log.d("exExp", ex.message);
            } finally {
                pdLoading?.dismiss()
            }

            return null
        }

        override fun onPostExecute(response: String) {
            super.onPostExecute(response)

            try {

                val parentobjt = JSONObject(response)

                Log.d("jsonStatus", "" + parentobjt)
                //Toast.makeText(Login.this,status+result+msg,Toast.LENGTH_LONG).show();
                if (parentobjt.getString("type").equals("success", true)) {
                    // userIdEdt.setText(parentobjt.getString("order_no"))

                    sendOrdNo = parentobjt.getString("order_no")
                    // ordChk.setText(sendOrdNo)
                    orderNumList = ArrayList()

                    for (i in 1..10) {
                        orderNumList!!.add(parentobjt.getString("order_no"))
                    }

                    var adapter = OrderAdapter(this@Create)
                    recyclerView.adapter = adapter

                } else {
                    Toast.makeText(this@Create, "" + parentobjt, Toast.LENGTH_SHORT).show()
                }

            } catch (e: JSONException) {
                e.printStackTrace()
            } catch (ex: Exception) {
                ex.printStackTrace()
                Log.d("expst", " Nullpointer exception")
            }

        }
    }

    fun getAddress(latLng: LatLng): String? {
        var countryName = ""
        var state = ""
        var town = ""
        var locality = ""
        var zip = ""



        try {
            val gcd = Geocoder(this@Create, Locale.getDefault())
            var addresses: List<Address>? = null
            addresses = gcd.getFromLocation(latLng.latitude, latLng.longitude, 1)
            if (addresses!!.size > 0) {
                countryName = addresses[0].countryName
                state = addresses[0].adminArea
                town = addresses[0].subAdminArea

                locality = addresses[0].locality
                zip = addresses[0].postalCode
            }
        } catch (e: Exception) {
            e.printStackTrace()
            return "updating"
        }


        return "$countryName $state $town $locality $zip"
    }

    // Date time picker

    fun getTime(textView: TextView, button: Button, context: Context) {

        val cal = Calendar.getInstance()

        textView.text = SimpleDateFormat("HH:mm").format(cal.time)

        val timeSetListener = TimePickerDialog.OnTimeSetListener { timePicker, hour, minute ->
            cal.set(Calendar.HOUR_OF_DAY, hour)
            cal.set(Calendar.MINUTE, minute)

            textView.text = SimpleDateFormat("HH:mm").format(cal.time)
        }

        button.setOnClickListener {
            TimePickerDialog(context, timeSetListener, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
        }
    }

    inner class OrderAdapter(val context: Context) : RecyclerView.Adapter<ViewHolder>() {

        // Gets the number of animals in the list
        override fun getItemCount(): Int {
            return orderNumList!!.size
        }

        // Inflates the item views
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            return ViewHolder(LayoutInflater.from(context).inflate(R.layout.item_order_number, parent, false))
        }

        // Binds each animal in the ArrayList to a view
        override fun onBindViewHolder(holder: ViewHolder, position: Int) {


            holder?.ordChk?.text = orderNumList!!.get(position).toString()


        }


    }

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        // Holds the TextView that will add each animal to

        val ordChk = view.findViewById<CheckBox>(R.id.ordChk)


    }
}


/*//Simple function for date picker
fun getDate(textView: TextView, context: Context){

    val cal = Calendar.getInstance()

    val dateSetListener = DatePickerDialog.OnDateSetListener { view, year, monthOfYear, dayOfMonth ->
        cal.set(Calendar.YEAR, year)
        cal.set(Calendar.MONTH, monthOfYear)
        cal.set(Calendar.DAY_OF_MONTH, dayOfMonth)

        textView.text = SimpleDateFormat("dd.MM.yyyy").format(cal.time)

    }

    textView.setOnClickListener {
        DatePickerDialog(context, dateSetListener,
                cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH),
                cal.get(Calendar.DAY_OF_MONTH)).show()
    }
}
presenter.getDate(textViewTime, this)
*/
