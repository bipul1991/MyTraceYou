package com.pearnode.blaze.triptoe;


import android.content.Intent;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;


/**
 * Created by Bipul on 12-Feb-18.
 */

public class MyFirebaseMessagingService extends FirebaseMessagingService

{

    public MyFirebaseMessagingService() {
    }

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        // ...

        // TODO(developer): Handle FCM messages here.
        // Not getting messages here? See why this may be: https://goo.gl/39bRNJ
        //  Log.i("messageCheck", "From: " + remoteMessage.getFrom());

        // Check if message contains a data payload.
      /*  if (remoteMessage.getData().size() > 0) {
            Log.i("messageCheck", "Message data payload: " + remoteMessage.getData());
        }*/

        // Check if message contains a notification payload.
        if (remoteMessage.getNotification() != null) {
            //   Log.i("messageCheck", "Message Notification Body: " + remoteMessage.getNotification().getBody());


            notifyUser(remoteMessage.getFrom(), remoteMessage.getNotification().getBody());
        }


    }

    public void notifyUser(String from, String notification) {
        Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
        MyNotificationManager myNotificationManager = new MyNotificationManager(getApplicationContext());
        myNotificationManager.showNotification(from, notification, intent);
    }


}
