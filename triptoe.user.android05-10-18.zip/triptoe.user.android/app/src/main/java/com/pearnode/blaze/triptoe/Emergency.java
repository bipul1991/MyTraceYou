package com.pearnode.blaze.triptoe;

import android.Manifest;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;


public class Emergency extends AppCompatActivity {

    ImageView imageView;
    Button btnCamera, btnGallery, btnSubmit;
    EditText descEdt;
    private int REQUEST_CAMERA = 0, SELECT_FILE = 1;

    int MY_PERMISSIONS_REQUEST_CAMERA = 123;

    String jobId = "";
    Uri currImageGURI = null;
    String gPath = "";
    public static final int PERMS_CODE = 123;


    File file;

    String msg = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emergency);


        imageView = (ImageView) findViewById(R.id.img);
        //  btnGallery = (Button) findViewById(R.id.btnGal);
        btnCamera = (Button) findViewById(R.id.btnCam);
        btnSubmit = (Button) findViewById(R.id.btnSubmit);
        descEdt = (EditText) findViewById(R.id.descEdt);
        Intent intent = getIntent();

        // askPermission();
        //  boolean permissionChk=  hasPermission();
        if (!hasPermission()) {
            requsetPerms();
        }


        jobId = intent.getStringExtra("id");

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                msg = descEdt.getText().toString();

                new SubmitAsync().execute("http://triptoe.pearnode.com/api_mobile/api/transport_accidental_issue", jobId, msg);

            }
        });

        btnCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cameraIntent();
            }
        });
       /* btnGallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                galleryIntent();
            }
        });*/
    }

    private void galleryIntent() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);//
        startActivityForResult(Intent.createChooser(intent, "Select File"), SELECT_FILE);
    }

    private void cameraIntent() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent, REQUEST_CAMERA);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == SELECT_FILE)
                onSelectFromGalleryResult(data);
            else if (requestCode == REQUEST_CAMERA)
                onCaptureImageResult(data);
        }
    }

    private void onSelectFromGalleryResult(Intent data) {
        Bitmap bm = null;
        if (data != null) {
            try {
                currImageGURI = data.getData();
                gPath = getRealPathFromURI(currImageGURI);


                bm = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), data.getData());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        imageView.setImageBitmap(bm);
    }

    private void onCaptureImageResult(Intent data) {
        Bitmap thumbnail = (Bitmap) data.getExtras().get("data");
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        thumbnail.compress(Bitmap.CompressFormat.JPEG, 90, bytes);

        File destination = new File(Environment.getExternalStorageDirectory(),
                System.currentTimeMillis() + ".jpg");

        file = destination;

        FileOutputStream fo;
        try {
            destination.createNewFile();
            fo = new FileOutputStream(destination);
            fo.write(bytes.toByteArray());
            fo.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        imageView.setImageBitmap(thumbnail);
    }

    public boolean askPermission() {

        if (ContextCompat.checkSelfPermission(this,
                "Manifest.permission.CAMERA")
                != PackageManager.PERMISSION_GRANTED) {
            return true;
        } else {
            ActivityCompat.requestPermissions(this,
                    new String[]{"Manifest.permission.CAMERA"},
                    MY_PERMISSIONS_REQUEST_CAMERA);
            askPermission();
            return false;
        }

    }

    public String getRealPathFromURI(Uri contentUri) {

        // can post image
        String[] proj = {MediaStore.Images.Media.DATA};
        Cursor cursor = managedQuery(contentUri,
                proj, // Which columns to return
                null,       // WHERE clause; which rows to return (all rows)
                null,       // WHERE clause selection arguments (none)
                null); // Order-by clause (ascending by name)
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();

        return cursor.getString(column_index);
    }

    public boolean hasPermission() {

        int res = 0;

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            return true;
        }

        String[] permissions = new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.READ_PHONE_STATE,
                Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.CAMERA
        };


        for (String perms : permissions) {

            res = checkCallingOrSelfPermission(perms);

            if (!(res == PackageManager.PERMISSION_GRANTED)) {

                return false;
            }
        }

        return true;

    }

    public void requsetPerms() {

        String[] permissions = new String[]{
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.READ_PHONE_STATE,
                Manifest.permission.ACCESS_FINE_LOCATION,

                Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.READ_CONTACTS, Manifest.permission.CAMERA,


        };

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

            requestPermissions(permissions, PERMS_CODE);

        }

    }

    public class SubmitAsync extends AsyncTask<String, String, String> {

        ProgressDialog pdLoading;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            pdLoading = new ProgressDialog(Emergency.this);
            pdLoading.setMessage("\tPlease wait...");
            pdLoading.setCancelable(false);
            pdLoading.show();

        }

        @Override
        protected String doInBackground(String... urls) {

            HttpURLConnection connection = null;
            BufferedReader reader = null;


//            File f = new File(data.getStringExtra(FilePickerActivity.RESULT_FILE_PATH));
            String content_type = getMimeType(file.getPath());

            OkHttpClient client = new OkHttpClient();

            String file_path = file.getAbsolutePath();

            RequestBody file_body = RequestBody.create(MediaType.parse(content_type), file);

            RequestBody request_body = new MultipartBody.Builder()
                    .setType(MultipartBody.FORM)
                    .addFormDataPart("id", jobId)
                    .addFormDataPart("accidental_issue", msg)
                    .addFormDataPart("accidental_proof", file_path.substring(file_path.lastIndexOf("/") + 1), file_body)
                    .build();

            Request request = new Request.Builder()
                    .url(urls[0])
                    .post(request_body)
                    .build();

            try {
                Response response = client.newCall(request).execute();


                String finaljson = response.body().string();

                return finaljson;


            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (Exception ex) {
                ex.printStackTrace();
            } finally {
                pdLoading.dismiss();
                if (connection != null) {
                    connection.disconnect();

                }
                try {
                    if (reader != null) {
                        reader.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            try {
                JSONObject jsonObject = new JSONObject(result);
                if (jsonObject.getString("type").equalsIgnoreCase("success")) {
                    Toast.makeText(Emergency.this, "Success", Toast.LENGTH_LONG).show();
                    finish();
                } else
                    Toast.makeText(Emergency.this, "Error", Toast.LENGTH_LONG).show();

            } catch (JSONException e) {
                e.printStackTrace();
            }


        }


    }

    private String getMimeType(String path) {

        String extension = MimeTypeMap.getFileExtensionFromUrl(path);


        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);

    }
}
// https://www.youtube.com/watch?v=G89GtT1JMEc