package com.pearnode.blaze.triptoe

import android.app.ProgressDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.AsyncTask
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.pearnode.blaze.triptoe.model.UserModel
import com.pearnode.blaze.triptoe.utils.NetworkUtil
import kotlinx.android.synthetic.main.activity_completed.*
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.*
import java.net.HttpURLConnection
import java.net.MalformedURLException
import java.net.URL

class ActiveTripsActivity : AppCompatActivity() {
    var userType = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_completed)
        recyclerView.layoutManager = LinearLayoutManager(this)

        setTitle("ActiveTripsActivity Transport")

        val editor = getSharedPreferences("truck", Context.MODE_PRIVATE)


        userType = editor.getString("type", "username")
        var userId = editor.getString("userId", "username")

        if (NetworkUtil.isConnected(this@ActiveTripsActivity)) {
            ActiveAsync().execute("http://triptoe.pearnode.com/api_mobile/api/transport_active", userId, userType)
        } else {
            Toast.makeText(this, "Please Check your internet connection", Toast.LENGTH_SHORT).show();
        }
    }

    inner class ActiveAsync : AsyncTask<String, String, String>() {


        internal var pdLoading: ProgressDialog? = null
        override fun onPreExecute() {
            super.onPreExecute()

            pdLoading = ProgressDialog(this@ActiveTripsActivity);
            pdLoading?.setMessage("\tLoding location...");
            pdLoading?.setCancelable(false);
            pdLoading?.show();

        }

        override fun doInBackground(vararg urls: String): String? {

            var connection: HttpURLConnection? = null
            var reader: BufferedReader? = null

            try {
                val url = URL(urls[0])
                connection = url.openConnection() as HttpURLConnection

                connection.readTimeout = 10000
                connection.connectTimeout = 15000
                connection.requestMethod = "POST"
                connection.doInput = true
                connection.doOutput = true

                val builder = Uri.Builder()
                        // user_id, transporter_id, current_lat, current_long, current_address, transport_desc, created_by
                        .appendQueryParameter("user_id", urls[1])
                        .appendQueryParameter("usertype", urls[2])


                val query = builder.build().query
                val os = connection.outputStream
                val writer = BufferedWriter(
                        OutputStreamWriter(os))
                writer.write(query)
                writer.flush()
                writer.close()
                os.close()
                connection.connect()

                val stream = connection.inputStream
                reader = BufferedReader(InputStreamReader(stream) as Reader?)

                var line: String? = ""
                val buffer = StringBuffer()

                /* while ((line = reader.readLine()) != null) {
                     buffer.append(line)
                 }*/

                do {
                    line = reader.readLine()

                    if (line == null)

                        break
                    else
                        buffer.append(line)
                    //  println(line)

                }
                // while (true)
                while (line == null)

                val finaljson = buffer.toString()

                //  val parentobjt = JSONObject(finaljson)

                //               ShippingAddressModel shippingAddressModel=new ShippingAddressModel();
                //
                //               shippingAddressModel.setMsg(parentobjt.getString("msg"));
                //               shippingAddressModel.setStatus(parentobjt.getBoolean("status"));

                Log.d("jsonAct", "" + finaljson)

                return finaljson

            } catch (e: MalformedURLException) {
                e.printStackTrace()
            } catch (e: IOException) {
                e.printStackTrace()
            } catch (e: JSONException) {
                e.printStackTrace()
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                pdLoading?.dismiss()
            }


            return null
        }

        override fun onPostExecute(response: String) {
            super.onPostExecute(response)

            try {

                val parentArray = JSONArray(response)

                // var arraylist: ArrayList<UserModel>?=null
                val modelList = ArrayList<UserModel>()

                for (x in 0..parentArray.length() - 1) {
                    var jsonObj: JSONObject = parentArray.getJSONObject(x);
                    // var userName=jsonObj.getString("user_name")

                    //   var userId=jsonObj.getString("user_id")

                    //   var tnsPtName=jsonObj.getString("transporter_name")
                    //    var tnsPtName=jsonObj.getString("transporter_name")
                    var transporter_id = jsonObj.getString("transporter_id")

                    var innerObj = jsonObj.getString("start_location")
                    var jObj = JSONObject(innerObj)
                    var address = jObj.getString("address")

                    var id = jsonObj.getString("id")
                    var userName = jsonObj.getString("start_address")
                    var tnsPtName = jsonObj.getString("current_address")
                    var userId = jsonObj.getString("order_id")

                    // user name= current address, tnsPtName=start address
                    //  userId= orderId

                    modelList.add(UserModel(userName, userId, tnsPtName, address, "123lat", "lung34", transporter_id, id))
                }
                var adapter = UserAdapter(modelList, this@ActiveTripsActivity)
                recyclerView.adapter = adapter

                //  recyclerView.adapter = UserAdapter(modelList!!, this@ActiveTripsActivity)


                //Toast.makeText(Login.this,status+result+msg,Toast.LENGTH_LONG).show();

            } catch (e: JSONException) {
                e.printStackTrace()
            } catch (ex: Exception) {
                ex.printStackTrace()
                Log.d("expst", " Nullpointer exception")
            }

        }
    }

    inner class UserAdapter(val items: ArrayList<UserModel>, val context: Context) : RecyclerView.Adapter<ViewHolder>() {

        // Gets the number of animals in the list
        override fun getItemCount(): Int {
            return items.size
        }

        // Inflates the item views
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            return ViewHolder(LayoutInflater.from(context).inflate(R.layout.itme_transport, parent, false))
        }

        // Binds each animal in the ArrayList to a view
        override fun onBindViewHolder(holder: ViewHolder, position: Int) {

            if (!userType.equals("3", true)) {
                //Turucker
                holder?.currntLay?.visibility = View.GONE
                holder?.startlay?.visibility = View.GONE
            }
            /* else
             {
                 //user
                // createTrnsLay.visibility = View.GONE

             }*/
            holder?.currentAdrTxt?.text = items.get(position).userName
            holder?.orderIdTxt?.text = items.get(position).userId
            holder?.startAdrTxt.text = items.get(position).transPname

            holder.itmLay.setOnClickListener(View.OnClickListener {
                val intent = Intent(context, MapsActivity::class.java)
                intent.putExtra("trsnId", items.get(position).id)
                intent.putExtra("type", "active")
                context.startActivity(intent)
                finish()
            })
        }


    }

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        // Holds the TextView that will add each animal to

        val currentAdrTxt = view.findViewById<TextView>(R.id.currentAdrTxt)
        val orderIdTxt = view.findViewById<TextView>(R.id.orderIdTxt)
        val startAdrTxt = view.findViewById<TextView>(R.id.startAdrTxt)
        val itmLay = view.findViewById<LinearLayout>(R.id.itmLay)
        val startlay = view.findViewById<LinearLayout>(R.id.startlay)
        val currntLay = view.findViewById<LinearLayout>(R.id.currntLay)

    }
}
